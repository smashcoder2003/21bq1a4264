package TextbookCodeSnippets;

public class CharDemo2 {
    public static void main(String[] args){
        char x = 88;
        System.out.println("x is : " + x);
        x -= 27;// x = x - 27
        System.out.println("x is : " + x);
    }
}
