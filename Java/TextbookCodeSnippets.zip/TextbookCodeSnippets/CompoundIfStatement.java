package TextbookCodeSnippets;

public class CompoundIfStatement {
    public static void main(String[] args){
        int x = 10,y=20;
        if(x<y){
            System.out.println("This is statement 1");
            System.out.println("This is statement 2");
        }
    }

}
