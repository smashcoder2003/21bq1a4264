package TextbookCodeSnippets.Arrays;

public class TwoDAgain {
    public static void main(String[] args){
        int[][] twoD = new int[4][];
        twoD[0] = new int[5];
        twoD[1] = new int[5];
        twoD[2] = new int[5];
        twoD[3] = new int[5];
    }
}
