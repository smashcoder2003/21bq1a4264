package TextbookCodeSnippets;

public class Example2 {
    public static void main(String[] args){
        int num;
        num = 100;
        System.out.println("The value of num: " +num);
        num = num * 2;
        System.out.println("The value of num: " + num);
    }
}
