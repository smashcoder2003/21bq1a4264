package TextbookCodeSnippets.Classes.Abstraction;

public final class FinalAsNonInheritor {
    void hello() {
        System.out.println("Hello!");
    }
}
/* class FinalAsNonInheritor2 extends FinalAsNonInheritor{ // super class can't be inherited because it is final.
    void hello() {
        System.out.println("hi!");
    }
}
*/