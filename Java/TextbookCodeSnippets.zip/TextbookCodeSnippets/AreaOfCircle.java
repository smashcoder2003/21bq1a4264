package TextbookCodeSnippets;

public class AreaOfCircle {
    public static void main(String[] args){
        double a,r,pi;
        pi = 3.1416;
        r = 2.234235;
        a = pi * r * r;
        System.out.println("The area of circle is: " + a);

    }
}
