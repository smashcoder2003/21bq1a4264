package TextbookCodeSnippets;

public class Promote {
    public static void main(String[] args){
        byte a = 27;
        short b = 288;
        int c = 1465;
        long d = 139081;
        float f = 5.67f;
        double g = .12124124;
        double result = (a * g) + (g-1) + (c/g);
        System.out.println(result);
    }
}
