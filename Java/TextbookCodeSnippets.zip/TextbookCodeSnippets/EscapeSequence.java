package TextbookCodeSnippets;

public class EscapeSequence {
    public static void main(String[] args){
        System.out.print("hello \r");
        System.out.print("world");
    }
}
