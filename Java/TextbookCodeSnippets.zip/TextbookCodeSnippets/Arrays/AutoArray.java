package TextbookCodeSnippets.Arrays;
public class AutoArray {
    public static void main(String[] args)
    {
        int[] month_days = {31,213,322,45,53,34,32,2};
        System.out.println("April has: " + (month_days[3]-15) + " days");
    }
}
