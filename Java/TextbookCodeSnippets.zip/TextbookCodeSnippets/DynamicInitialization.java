package TextbookCodeSnippets;

public class DynamicInitialization {
    public static void main(String[] args) {
        double a = 1.22323, b = 3.2342;
        double c = Math.sqrt(a * a + b * b);
        System.out.print(c);
    }
}
