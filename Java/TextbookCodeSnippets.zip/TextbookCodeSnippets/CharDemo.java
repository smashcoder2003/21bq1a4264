package TextbookCodeSnippets;

public class CharDemo {
    public static void main(String[] args){
        char x,y;
        x = 88;// Ascii code
        y = 'Y';
        System.out.println("x and y are: " + x + "," + y);
    }
}
